# Portfólio – Integração e Entrega Contínua – 2026/1
## Aluno
- Nome: Rafael Shinji Tomokame
- LinkedIn:
- GitHub: https://github.com/RafaelShinjiTomokame
---
## Estrutura
- P1
- P2
- Requisitos-ABP
- Reflexoes
---
## Projeto ABP
Descrição do problema escolhido.
---
## Aprendizados
Registro reflexivo sobre evolução no semestre.
